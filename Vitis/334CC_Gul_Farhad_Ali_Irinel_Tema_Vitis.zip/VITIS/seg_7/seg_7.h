
#include <ap_int.h>

#define SIGNAL_PERIOD 400000

//#define SIGNAL_PERIOD 10  // Doar pentru simulare

