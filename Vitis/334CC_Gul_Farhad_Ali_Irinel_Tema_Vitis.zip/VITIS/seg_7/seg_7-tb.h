
#pragma once

#include "seg_7.h"

void seg_7(bool &out_signal);
